from GameView import window
w = window()
w.Main()
