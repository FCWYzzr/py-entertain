from GameStage.test import Test
GameStages={
    "test": Test()
}
